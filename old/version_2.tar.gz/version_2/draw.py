import pygame, os, copy, time, random
import level_parser

# Here is what needs to be set before game can start:
#
# Load config file
#
# Then do reset()

BLINKY = 0
PINKY = 1
INKY = 2
CLYDE = 3
BLUE = 4
WHITE = 5

#class Ghost:
#	def __init__(self):
#		pass
#
#	def get_ghost_direction(self, ghost_id):
#		seed = random.randint(0,3)
#		if (seed == 0):
#			dir = 'r'
#		elif (seed == 1):
#			dir = 'l'
#		elif (seed == 2):
#			dir = 'u'
#		else:
#			dir = 'd'
#
#		return dir

class PacmanError(Exception):
	pass

class Drawer:

	def __init__(self, surface, config_file_name):
		# This will be our drawing canvas
		self.canvas = surface
		
		# Load config options
		# TODO: write comments about config options
		try:
			config = open(config_file_name, 'r')
			self.config_options = eval(config.read())
			config.close()
		except:
			raise PacmanError('Configuration file failed to load')

		self.next_level = 0
		
		self.config_file_name = config_file_name
		self.tile_images = {}

		# Pacman image list
		self.pacman_images = []

		# ---------------------------------------------
		# Ghost attributes
		
		# Ghost image dictionaries
		self.ghost_images = {}
		self.ghost_image = {}
		self.current_ghost_image = {}
		self.ghost_rect	 = {}
		self.ghost_mode = {}
		self.ghost_direction = {}
		self.next_ghost_direction = {}
		
		# Ghost colors
		self.ghostcolor = {}
		self.ghostcolor[BLINKY] = (255, 0, 0, 255)		# Red, Blinky ghost
		self.ghostcolor[PINKY] = (255, 128, 255, 255)	# Pink, Pinky ghost
		self.ghostcolor[INKY] = (128, 255, 255, 255)	# Cyan, Inky ghost
		self.ghostcolor[CLYDE] = (255, 128, 0, 255)		# Orange, Clyde ghost
		self.ghostcolor[BLUE] = (50, 50, 255, 255)		# Blue, vulnerable ghost
		self.ghostcolor[WHITE] = (255, 255, 255, 255)	# White, flashing ghost
		# ---------------------------------------------

	def get_tile_size(self):
		"Returns the tile size for the level"
		return self.level.tile_size

	def load_level(self, filename):
		"Loads a new level from a file, given the filename. "
		self.level.parse_file(filename)

	def out_of_bounds(self, position):
		"Returns whether the given position is out of bounds. "
		if position[0] >= self.level.level_dim[0] * self.level.tile_size:
			return True
		if position[0] <= 0:
			return True
		if position[1] >= self.level.level_dim[1] * self.level.tile_size:
			return True
		if position[1] <= 0:
			return True
		return False

	def get_relevant_corners(self, rect, move, velocity):
		"Returns a tuple that contains the corners to check for collisions \
		given the move and velocity for the given rect"
		if move == 'u':
			first_corner = (rect.topleft[0], rect.topleft[1] - velocity)
			second_corner = (rect.topright[0], rect.topright[1] - velocity)
		elif move == 'd':
			first_corner = (rect.bottomleft[0], rect.bottomleft[1] + velocity)
			second_corner = (rect.bottomright[0], rect.bottomright[1] + velocity)
		elif move == 'l':
			first_corner = (rect.topleft[0] - velocity, rect.topleft[1])
			second_corner = (rect.bottomleft[0] - velocity, rect.bottomleft[1])
		elif move == 'r':
			first_corner = (rect.topright[0] + velocity, rect.topright[1])
			second_corner = (rect.bottomright[0] + velocity, rect.bottomright[1])
		else:
			raise PacmanError("Invalid move")
		return (first_corner, second_corner)
		

	def is_valid_move(self, ai_name, move):
		"Returns whether the move is valid (i.e., won't hit a wall)"
		
		if ai_name == "pacman":
			rect = self.pacman_rect
			velocity = self.config_options['pacman_velocity']
		else:
			rect = self.ghost_rect[int(ai_name[-1])]
			velocity = self.config_options['ghost_velocity']

		# The first and second corners represent the side of pacman most likely to cause an event, like
		# get out of bounds or hit a wall
		first_corner, second_corner = self.get_relevant_corners(rect, move, velocity)

		if move == 'u' and first_corner[1] <= 0:
			return True
		elif move == 'd' and first_corner[1] >= self.level.level_dim[1] * self.level.tile_size:
			return True
		elif move == 'l' and first_corner[0] <= 0:
			return True
		elif move == 'r' and first_corner[0] >= self.level.level_dim[0] * self.level.tile_size:
			return True
		elif self.out_of_bounds(first_corner):
			return False

		# Wall
		if self.is_wall(first_corner) or self.is_wall(second_corner):
			return False

		# Ghost Door
		if (ai_name != "pacman") and (num_moves[int(ai_name)] > num_first_ghost_moves[int(ai_name)]) and \
			 (self.is_ghost_door(first_corner) or self.is_ghost_door(second_corner)):
		#print "Ghost " + ai_name + " tried to go through the ghost door when he shouldn't have."
			return False

		return True

	def update_pacman(self):
		"1 - Initial state\
		2 - Wall \
		3 - Empty tile \
		4 - Pellet \
		5 - Power pellet \
		6 - Hit normal ghost \
		7 - Hit vulnerable ghost"

		# Pacman is in initial state, don't do anything
		if self.next_pacman_direction == 's':
			return 1

		if self.is_valid_move("pacman", self.next_pacman_direction):
			self.current_pacman_direction = self.next_pacman_direction
		
		if self.current_pacman_direction == 's':
			return 1

		# Wall
		if not self.is_valid_move("pacman", self.current_pacman_direction):
			self.pacman_immobile = 1
			return 2
		
		self.pacman_immobile = 0

		if self.current_pacman_direction == 'u':
			self.pacman_image = map(lambda x: pygame.transform.rotate(x, 90), self.pacman_images)
			position_offset = (0, -self.config_options['pacman_velocity'])
		elif self.current_pacman_direction == 'd':
			self.pacman_image = map(lambda x: pygame.transform.rotate(x, -90), self.pacman_images)
			position_offset = (0, self.config_options['pacman_velocity'])
		elif self.current_pacman_direction == 'l':
			self.pacman_image = map(lambda x: pygame.transform.flip(x, 1, 0), self.pacman_images)
			position_offset = (-self.config_options['pacman_velocity'], 0)
		elif self.current_pacman_direction == 'r':
			self.pacman_image = self.pacman_images
			position_offset = (self.config_options['pacman_velocity'], 0)

		# Get relevant corners to check for events
		first_corner, second_corner = self.get_relevant_corners(self.pacman_rect, self.current_pacman_direction, \
									  self.config_options['pacman_velocity'])
		
		# Effect current move
		self.pacman_rect.topleft = (self.pacman_rect.topleft[0] + position_offset[0], self.pacman_rect.topleft[1] \
									+ position_offset[1])

		# This is for wraparound world
		if first_corner[0] >= self.level.level_dim[0] * self.level.tile_size:
			self.pacman_rect.topleft = (0, self.pacman_rect.topleft[1])
		elif first_corner[1] >= self.level.level_dim[1] * self.level.tile_size:
			self.pacman_rect.topleft = (self.pacman_rect.topleft[0], 0)
		elif first_corner[0] <= 0:
			self.pacman_rect.topleft = (self.level.level_dim[0] * self.level.tile_size - self.level.tile_size, \
										self.pacman_rect.topleft[1])
		elif first_corner[1] <= 0:
			self.pacman_rect.topleft = (self.pacman_rect.topleft[0], \
										self.level.level_dim[1] * self.level.tile_size - self.level.tile_size)

		# Pellet
		if self.is_pellet(self.pacman_rect.topleft) or self.is_pellet(self.pacman_rect.bottomright):
			self.level.num_pellets -= 1
			self.clear_tile(self.pacman_rect.topleft)
			self.clear_tile(self.pacman_rect.bottomright)
			return 4

		# Power pellet
		if self.is_power_pellet(self.pacman_rect.topleft) or self.is_power_pellet(self.pacman_rect.bottomright):
			self.level.num_pellets -= 1
			self.clear_tile(self.pacman_rect.topleft)
			self.clear_tile(self.pacman_rect.bottomright)
			self.set_ghost_mode_all(1)
			return 5

		# Collision with a ghost
		for i in range(4):
			if self.pacman_rect.colliderect(self.ghost_rect[i]):
				# Ghost is normal, pause for a second and reset ghosts and pacman
				if self.ghost_mode[i] == 0:
					time.sleep(1)
					self.reset_agents()
					return 6
				# Ghost is vulnerable
				else:
					self.set_ghost_mode(i, 2)
					return 7

		# Empty tile
		if self.is_clear(self.pacman_rect.topleft) and self.is_clear(self.pacman_rect.bottomright):
			return 3

	def update_ghost(self, ghost_id):
		"1 - Wall \
		2 - Hit Pacman normal \
		3 - Hit Pacman vulnerable"

	#print "update_ghost " + str(ghost_id)

		# Pacman is in initial state, don't do anything
		#if self.next_pacman_direction == 's':
		#	return 1

		#if self.is_valid_move("pacman", self.next_pacman_direction):
		#	self.current_pacman_direction = self.next_pacman_direction
		
		#if self.current_pacman_direction == 's':
		#	return 1

		# ghost is in initial state, don't do anything
		if self.next_ghost_direction[ghost_id] == 's':
		#print "Ghost " + str(ghost_id) + " is not moving."
			return 4

		dir = self.ghost_direction[ghost_id]
		if self.is_valid_move(str(ghost_id), self.next_ghost_direction[ghost_id]):
		#print "Ghost " + str(ghost_id) + " is setting next direction to " + self.next_ghost_direction[ghost_id]
			self.ghost_direction[ghost_id] = self.next_ghost_direction[ghost_id]

		if self.ghost_direction[ghost_id] == 's':
		#print "Ghost " + str(ghost_id) + " is in initial state."
			return 4

		# Wall
		if not self.is_valid_move(str(ghost_id), self.ghost_direction[ghost_id]):
		#print "Ghost " + str(ghost_id) + " tried to move into a wall"
			return 1

		if self.ghost_direction[ghost_id] == 'u':
			position_offset = (0, -self.config_options['ghost_velocity'])
		elif self.ghost_direction[ghost_id] == 'd':
			position_offset = (0, self.config_options['ghost_velocity'])
		elif self.ghost_direction[ghost_id] == 'l':
			position_offset = (-self.config_options['ghost_velocity'], 0)
		elif self.ghost_direction[ghost_id] == 'r':
			position_offset = (self.config_options['ghost_velocity'], 0)

	#print "Ghost " + str(ghost_id) + " getting relevant corners."
		# Get relevant corners to check for events
		first_corner, second_corner = self.get_relevant_corners(self.ghost_rect[ghost_id], \
		                                                        self.ghost_direction[ghost_id], \
		                                                        self.config_options['ghost_velocity'])
		
	#print "Ghost " + str(ghost_id) + " setting new postion"
		# Effect current move
		self.ghost_rect[ghost_id].topleft = (self.ghost_rect[ghost_id].topleft[0] + position_offset[0], \
		                            self.ghost_rect[ghost_id].topleft[1] + position_offset[1])

		# Ghost turned, thus making a move
		if (dir != self.ghost_direction[ghost_id]):
		#print "Incrementing num_moves"
			num_moves[ghost_id] += 1

		# Got hit in vulnerable mode previously
		if self.get_ghost_mode(ghost_id) == 2:
		#print "Ghost " + str(ghost_id) + " is eyes."
			return 3

		# Collision with Pacman
		if self.ghost_rect[ghost_id].colliderect(self.pacman_rect):
			# Ghost is normal, pause for a second and reset ghosts and pacman
			if self.ghost_mode[ghost_id] == 0:
			#print "Ghost " + str(ghost_id) + " hit pacman"
				time.sleep(1)
				self.reset_agents()
				return 2
			# Ghost is vulnerable
			else:
			#print "Ghost " + str(ghost_id) + " was eaten by pacman."
				self.set_ghost_mode(ghost_id, 2)
				return 3

		# This is for wraparound world
		if first_corner[0] >= self.level.level_dim[0] * self.level.tile_size:
			self.ghost_rect[ghost_id].topleft = (0, self.ghost_rect[ghost_id].topleft[1])
		elif first_corner[1] >= self.level.level_dim[1] * self.level.tile_size:
			self.ghost_rect[ghost_id].topleft = (self.ghost_rect[ghost_id].topleft[0], 0)
		elif first_corner[0] <= 0:
			self.ghost_rect[ghost_id].topleft = (self.level.level_dim[0] * self.level.tile_size - self.level.tile_size, \
										self.ghost_rect[ghost_id].topleft[1])
		elif first_corner[1] <= 0:
			self.ghost_rect[ghost_id].topleft = (self.ghost_rect[ghost_id].topleft[0], \
										self.level.level_dim[1] * self.level.tile_size - self.level.tile_size)

		# TODO: Need to return something

	def set_pacman_direction(self, direction):
		"Sets the next direction of pacman"
		self.next_pacman_direction = direction

	def set_ghost_direction(self, ghost_id, direction):
		"Sets the next direction for a ghost"

	#print "set_ghost_direction"

		if ghost_id > 3 or ghost_id < 0:
			raise PacmanError("Ghost ID out of range")

	#print "next_ghost_direction[" + str(ghost_id) + "] = " + direction
		self.next_ghost_direction[ghost_id] = direction

	def get_pacman_position(self):
		"Returns pacman's current position"
		return self.pacman_rect.topleft

	def get_pacman_home_position(self):
		"Returns pacman's home position"
		return self.level.pacman_home
	
	def get_ghost_mode( self, ghost_id):
		return self.ghost_mode[ghost_id]

	def get_ghost_position(self, ghost_id):
		"Returns the position of the ghost corresponding to the \
		give ghost_id"
		if ghost_id > 3 or ghost_id < 0:
			raise PacmanError("Ghost ID out of range")
		return self.ghost_rect[ghost_id].topleft

	def get_all_ghost_positions(self):
		"Returns the positions of all the ghosts"
		return map(lambda x: self.ghost_rect[x].topleft, [0, 1, 2, 3])

	def get_ghost_home_position(self, ghost_id):
		"Returns the home position of a specific ghost"
		if ghost_id > 3 or ghost_id < 0:
			raise PacmanError("Ghost ID out of range")
		return self.level.ghost_home[ghost_id]

	def get_all_ghost_home_positions(self):
		"Returns the home position for all the ghosts"
		return self.level.ghost_home

	def is_clear(self, position):
		return self.level.level_layout[int(position[1] / self.level.tile_size)][int(position[0] / self.level.tile_size)] == "0"

	def is_wall(self, position):
		"Returns whether the tile at the given position is a wall"
		x = int(position[1] / self.level.tile_size)
		y = int(position[0] / self.level.tile_size)
		return int(self.level.level_layout[x][y]) >= 100

	def is_ghost_door(self, position):
		"Returns whether the tile at the given position is the ghost door"
		x = int(position[1] / self.level.tile_size)
		y = int(position[0] / self.level.tile_size)
		return int(self.level.level_layout[x][y]) == 1

	def is_pellet(self, position):
		"Returns whether the tile at the given position is a pellet"
		return self.level.level_layout[int(position[1] / self.level.tile_size)][int(position[0] / self.level.tile_size)] == "2"

	def is_power_pellet(self, position):
		"Returns whether the tile at the given position is a power pellet"
		return self.level.level_layout[int(position[1] / self.level.tile_size)][int(position[0] / self.level.tile_size)] == "3"

	def clear_tile(self, position):
		"Clears the given tile"
		self.level.level_layout[int(position[1] / self.level.tile_size)][int(position[0] / self.level.tile_size)] = "0"

	def reset_ghost_timer(self, ghost_id):
		"Resets the time for the ghost that corresponds to ghost_id"
		if ghost_id < 0 or ghost_id > 3:
			raise PacmanError("Ghost ID out of range")
		self.ghost_time[ghost_id] = self.config_options['ghost_timer']

	def reset_all_ghost_timers(self):
		"Resets all the ghost timers"
		self.ghost_timer = [self.config_options['ghost_timer']] * 4

	def set_ghost_mode(self, ghost_id, mode):
		"Sets the mode for the ghost identified by ghost_id"
		if ghost_id < 0 or ghost_id > 3:
			raise PacmanError("Ghost ID out of range")
		if mode < 0 or mode > 2:
			raise PacmanError("Invalid ghost mode")

		if self.ghost_mode[ghost_id] != 2:
			self.ghost_mode[ghost_id] = mode

		# Set image array (for color) according to mode
		if mode == 2:
			pass
		elif mode == 1:
			self.ghost_image[ghost_id] = self.ghost_images[4]
		else:
			self.ghost_image[ghost_id] = self.ghost_images[ghost_id]
		self.ghost_timer[ghost_id] = self.config_options['ghost_timer']

	def set_ghost_mode_all(self, mode):
		"Sets the mode for all the ghosts"
		if mode < 0 or mode > 1:
			raise PacmanError("Invalid ghost mode chosen for all")

		for i in range(4):
			if self.ghost_mode[i] != 2:
				self.set_ghost_mode(i, mode)

		# Set image array (for color) according to mode
		if mode == 1:
			self.ghost_image = [self.ghost_images[4]] * 4
		else:
			self.ghost_image = [self.ghost_images[i] for i in [0, 1, 2, 3]]
		self.ghost_timer = [self.config_options['ghost_timer']] * 4

	def change_tile_color(self, tile, old_color, new_color):
		"Changes any pixel in the given tile from old_color to new_color"
		for y in range(self.level.tile_size):
			for x in range(self.level.tile_size):
				if tile.get_at((x, y)) == old_color:
					tile.set_at((x, y), new_color)

	def build_image_path(self, image_name):
		"Makes an OS specific path to the given image name"
		return os.path.join(self.config_options['image_path'], image_name)

	def reset_agents(self):
		"Resets agents"

		# --------------------------------------------
		# Set default pacman attributes
		
		self.pacman_image_index = 0
		self.current_pacman_direction = 's'
		self.next_pacman_direction = 's'
		self.pacman_immobile = 1
		image_path = self.build_image_path(self.config_options['still_pacman_image'])
		self.current_pacman_image = pygame.image.load(image_path).convert()
		self.pacman_rect = self.current_pacman_image.get_rect()
		self.pacman_rect = self.pacman_rect.inflate(-1, -1)
		self.pacman_rect.topleft = self.level.pacman_home
		# --------------------------------------------

		# --------------------------------------------
		# Set default ghost attributes
	
		self.next_ghost_direction = ['s', 's', 's', 's']	
		self.ghost_direction = ['s', 's', 's', 's']	
		self.reset_all_ghost_timers()
		self.ghost_image_index = 0
		for i in range(4):
			# reset number of moves for all ghosts to 0. This allows them to perform
			# their initial moves to get out of the ghost pen.
			num_moves[i] = 0
			self.ghost_image[i] = self.ghost_images[i]
			self.current_ghost_image[i] = self.ghost_image[i][self.ghost_image_index]
			self.ghost_rect[i] = self.current_ghost_image[i].get_rect()
			self.ghost_rect[i] = self.ghost_rect[i].inflate(-1, -1)
			self.ghost_rect[i].topleft = self.get_ghost_home_position(i)
		self.ghost_mode = [0, 0, 0, 0]
		# --------------------------------------------

	def load_next_level(self):
		"Reset everything to default state"
		# Load next level
		try:
			level_file_name = self.config_options['level_files'][self.next_level]
			self.num_levels = len(self.config_options['level_files'])
			self.level = level_parser.Level(level_file_name)
			self.next_level = (self.next_level + 1) % self.num_levels
		except:
			raise PacmanError('Level file ' + level_file_name + ' did not load properly')

		# Set frame delay
		self.delay = self.config_options['frame_delay']

		# Set power pellet blinking attributes
		self.blink_time = self.config_options['blink_time']
		self.on_off = 0
		
		# Load level tile images
		for tile in self.config_options['context_dictionary']:
			image_path = self.build_image_path(self.config_options['context_dictionary'][tile])
			self.tile_images[tile] = pygame.image.load(image_path).convert()

		# Set colors
		for tile in self.tile_images:
			# Wall edge color
			self.change_tile_color(self.tile_images[tile], (255, 206, 255, 255), self.level.color_edge)
			# Wall fill color
			self.change_tile_color(self.tile_images[tile], (132, 0, 132, 255), self.level.color_fill)
			# Wall edge shadow color
			self.change_tile_color(self.tile_images[tile], (255, 0, 255, 255), self.level.color_shadow)
			# Pellet color
			self.change_tile_color(self.tile_images[tile], (128, 0, 128, 255), self.level.color_pellet)

		# Load Pac-Man images
		for image_name in self.config_options['active_pacman_images']:
			image_path = self.build_image_path(image_name)
			self.pacman_images.append(pygame.image.load(image_path).convert())
		self.pacman_image_count = len(self.config_options['active_pacman_images'])

		# Load ghost images
		for i in range(6):
			self.ghost_images[i] = []
			for image_name in self.config_options['ghost_images']:
				image_path = self.build_image_path(image_name)
				self.ghost_images[i].append(pygame.image.load(image_path).convert())

				# Change the tile color for each ghost
				if i != 0:
					self.change_tile_color(self.ghost_images[i][self.config_options['ghost_images'].index(image_name)], (255, 0, 0, 255), self.ghostcolor[i])
		self.ghost_image_count = len(self.config_options['ghost_images'])

		self.reset_agents()

	def extract_left_eye_rect(self):
		"Extracts the left eye rect using the range given in the config file"
		return pygame.Rect(self.config_options['ghost_eye_range'][0][0], self.config_options['ghost_eye_range'][1][0], \
							self.config_options['ghost_eye_range'][0][1] - self.config_options['ghost_eye_range'][0][0] + 1, \
							self.config_options['ghost_eye_range'][1][1] - self.config_options['ghost_eye_range'][1][0] + 1)

	def extract_right_eye_rect(self):
		"Extracts the right eye rect using the range given in the config file"
		return pygame.Rect(self.config_options['ghost_eye_range'][0][0] + self.config_options['ghost_eye_offset'], \
							self.config_options['ghost_eye_range'][1][0], \
							self.config_options['ghost_eye_range'][0][1] - self.config_options['ghost_eye_range'][0][0] + 1, \
							self.config_options['ghost_eye_range'][1][1] - self.config_options['ghost_eye_range'][1][0] + 1)

	def draw(self):
		"Draws level, pacman, ghosts, and pellets"
		# First, draw level.  Do it tile by tile
		row = 0
		col = 0
		while row < self.level.level_dim[1]:
			while col < self.level.level_dim[0]:
				tile_id = self.level.level_layout[row][col]
				if int(tile_id) in self.tile_images:
					tile = self.tile_images[int(tile_id)]

					x_coord = col * self.level.tile_size
					y_coord = row * self.level.tile_size
					if self.blink_time == 0:
						self.on_off = (self.on_off + 1) % 2
						self.blink_time = self.config_options['blink_time']
					if not int(tile_id) == 3 or self.on_off:
						self.canvas.blit(tile, (x_coord, y_coord))
				col += 1
				
			row+= 1
			col = 0
		self.blink_time -= 1

		if self.delay == 0:
			if not self.pacman_immobile and self.current_pacman_direction != 's':
				self.pacman_image_index = (self.pacman_image_index + 1) % self.pacman_image_count
			self.ghost_image_index = (self.ghost_image_index + 1) % self.ghost_image_count
			self.delay = self.config_options['frame_delay']
		self.delay -= 1

		# Then draw the ghosts
		for i in range(4):
			if self.ghost_mode[i] == 1:
				# Ghost is vulnerable
				if self.ghost_timer[i] == 0:
					# Timer ran out, set mode to normal
					self.set_ghost_mode(i, 0)
				else:
					# Flashing ghost
					if self.ghost_timer[i] <= self.config_options['flash_timer']:
						if not self.ghost_timer[i] % 10:
							self.ghost_image[i] = self.ghost_images[((self.ghost_timer[i] / 10) % 2) + 4]
					self.ghost_timer[i] -= 1

			# Get the current ghost image for this frame
			self.current_ghost_image[i] = self.ghost_image[i][self.ghost_image_index]

			# -------------------------------------------
			# ghost eyes
			
			# Extract the left eye pixels
			left_eye_rect = self.extract_left_eye_rect()
			left_eye_image = self.current_ghost_image[i].subsurface(left_eye_rect).convert_alpha()

			# Extract the right eye pixels
			right_eye_rect = self.extract_right_eye_rect()
			right_eye_image = self.current_ghost_image[i].subsurface(right_eye_rect).convert_alpha()

			h_flip = 0
			v_flip = 0
			# Pacman is above us, flip vertically
			if self.get_pacman_position()[1] < self.get_ghost_position(i)[1]:
				left_eye_image = pygame.transform.flip(left_eye_image, 0, 1)
				right_eye_image = pygame.transform.flip(right_eye_image, 0, 1)
				h_flip = 1

			# Pacman is to our right, flip horizontally
			if self.get_pacman_position()[0] > self.get_ghost_position(i)[0]:
				left_eye_image = pygame.transform.flip(left_eye_image, 1, 0)
				right_eye_image = pygame.transform.flip(right_eye_image, 1, 0)
				v_flip = 1

			# Now draw the ghost
			if self.ghost_mode[i] != 2:
				self.canvas.blit(self.current_ghost_image[i], self.ghost_rect[i].topleft)
			coord = self.get_ghost_position(i)

			# And draw its eyes on top of it
			self.canvas.blit(left_eye_image, (coord[0] + left_eye_rect.left, coord[1] + left_eye_rect.top))
			self.canvas.blit(right_eye_image, (coord[0] + right_eye_rect.left, coord[1] + right_eye_rect.top))

			# Reset eye pixels to default
			if h_flip:
				left_eye_image = pygame.transform.flip(left_eye_image, 0, 1)
				right_eye_image = pygame.transform.flip(right_eye_image, 0, 1)
			if v_flip:
				left_eye_image = pygame.transform.flip(left_eye_image, 1, 0)
				right_eye_image = pygame.transform.flip(right_eye_image, 1, 0)
			#----------------------------------------------

		# Then draw pacman
		if self.current_pacman_direction != 's':
			self.current_pacman_image = self.pacman_image[self.pacman_image_index]

		# Put everything on the canvas
		self.canvas.blit(self.current_pacman_image, self.pacman_rect.topleft)
		
		if self.level.num_pellets == 0:
			time.sleep(1)
			self.load_next_level()

###############################################################################

	def get_ghost_direction(self, ghost_id):
		"This is the random ghost ai"

	#print "get_ghost_direction"

	#print "num_moves[" + str(ghost_id) + "] is " + str(num_moves[ghost_id])
		if (num_moves[ghost_id] < num_first_ghost_moves[ghost_id]):
			#print "Ghost " + str(ghost_id) + " is making an initial move."
			dir = first_ghost_moves[ghost_id][num_moves[ghost_id]]
		#print "Moving " + dir
			return dir

		seed = random.randint(0,3)

	#print "seed: " + str(seed)
		
		if (seed == 0) and (self.ghost_direction[ghost_id] != 'l'):
			dir = 'r'
		elif (seed == 1) and (self.ghost_direction[ghost_id] != 'r'):
			dir = 'l'
		elif (seed == 2) and (self.ghost_direction[ghost_id] != 'd'):
			dir = 'u'
		elif (seed == 3) and (self.ghost_direction[ghost_id] != 'u'):
			dir = 'd'
		else:
			#print "Random number generator picked an invalid number."
			#dir = 's'
		#print "Ghost tried to move backwards"
			dir = self.ghost_direction[ghost_id]

		return dir

	def get_first_blinky_dir(self):
		"This shouldn't be needed, but is used to set blinky's initial direction \
		so that he doesn't get stuck in his initial position."

		seed = random.randint(0,1)
		if( seed == 0 ):
			return 'l'
		return 'r'

num_first_ghost_moves = [1,2,1,2]
#first_ghost_moves = [[], ['r','u'], ['u'], ['l','u']]
first_ghost_moves = {}
first_ghost_moves[BLINKY] = ['l']
first_ghost_moves[PINKY]  = ['r','u']
first_ghost_moves[INKY]   = ['u']
first_ghost_moves[CLYDE]  = ['l','u']
num_moves = [0,0,0,0]
