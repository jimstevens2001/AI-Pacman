class Level:
	def __init__(self, filename=None):
		if filename:
			self.parse_file(filename)
	
	def parse_file(self, filename):
		self.filename = filename

		inFile = open(filename, 'r')
		lines = inFile.readlines()
		inFile.close()
		lines = [i.strip() for i in lines]

		self.num_pellets = int(lines[0].split(' ', 1)[1])
		self.tile_size = int(lines[1].split(' ', 1)[1])
		self.pacman_home = eval(lines[2].split(' ', 1)[1])
		self.ghost_home = eval(lines[3].split(' ', 1)[1])
		self.level_dim = eval(lines[4].split(' ', 1)[1])
		self.color_edge = eval(lines[5].split(' ', 1)[1])
		self.color_fill = eval(lines[6].split(' ', 1)[1])
		self.color_shadow = eval(lines[7].split(' ', 1)[1])
		self.color_pellet = eval(lines[8].split(' ', 1)[1])
		self.level_layout = [i.split() for i in lines[9:]]


	


