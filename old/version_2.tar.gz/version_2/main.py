import pygame, sys, os, time, random
import draw, level_parser
from pygame.locals import *

def get_level_specs(level):
	if level == 1:
		tiles_x = 21
		tiles_y = 25
		pacman = (10*16, 16*16)
		ghosts = [(10*16, 10*16), (9*16, 12*16), (10*16, 12*16), (11*16, 12*16)]
	elif level == 2:
		tiles_x = 33
		tiles_y = 23
		pacman = (16*16, 14*16)
		ghosts = [(16*16, 7*16), (15*16, 9*16), (16*16, 9*16), (17*16, 9*16)]
	elif level == 3:
		tiles_x = 21
		tiles_y = 25
		pacman = (10*16, 19*16)
		ghosts = [(10*16, 8*16), (9*16, 10*16), (10*16, 10*16), (11*16, 10*16)]
	elif level == 4:
		tiles_x = 21
		tiles_y = 23
		pacman = (10*16, 16*16)
		ghosts = [(10*16, 10*16), (9*16, 12*16), (10*16, 12*16), (11*16, 12*16)]
	elif level == 5:
		tiles_x = 21
		tiles_y = 23
		pacman = (10*16, 15*16)
		ghosts = [(10*16, 9*16), (9*16, 11*16), (10*16, 11*16), (11*16, 11*16)]
	elif level == 6:
		tiles_x = 21
		tiles_y = 23
		pacman = (10*16, 10*16)
		ghosts = [(10*16, 15*16), (9*16, 17*16), (10*16, 17*16), (11*16, 17*16)]
	elif level == 7:
		tiles_x = 21
		tiles_y = 23
		pacman = (10*16, 15*16)
		ghosts = [(17*16, 7*16), (16*16, 9*16), (17*16, 9*16), (18*16, 9*16)]
	elif level == 8:
		tiles_x = 34
		tiles_y = 33
		pacman = (7*16, 20*16)
		ghosts = [(20*16, 12*16), (19*16, 14*16), (20*16, 14*16), (21*16, 14*16)]	

	filename = "level" + str(level) + ".txt"
	return (tiles_x, tiles_y, filename, pacman, ghosts)
	

if __name__ == "__main__":

	clock = pygame.time.Clock()
	pygame.init()
	
	config = open(os.path.join('config', 'config.txt'), 'r')
	config_options = eval(config.read())
	config.close()
	level_file_name = config_options['level_files'][0]
	level = level_parser.Level(level_file_name)
	
	#tiles_x, tiles_y, filename, pacman_home, ghosts_home = get_level_specs(8)
	#width = tiles_x * 16
	#height = tiles_y * 16
	
	pygame.display.set_caption("PLAK-Man")
	window = pygame.display.set_mode((level.level_dim[0] * level.tile_size, level.level_dim[1] * level.tile_size))
	pygame.display.set_icon(pygame.transform.scale(pygame.image.load("images/pacman-r3.gif").convert(), (32, 32)))
	screen = pygame.display.get_surface()
	
	background = pygame.Surface(screen.get_size())
	background = background.convert()
	background.fill((0,0,0))

	screen.blit(background, (0,0))
	pygame.display.flip()
	
	drawer = draw.Drawer(screen, os.path.join('config', 'config.txt'))
	drawer.load_next_level()

	velX = 0
	velY = 0
	while True:
	
		pygame.event.pump()
		if pygame.key.get_pressed()[pygame.K_ESCAPE]:
			sys.exit(0)
			
		elif pygame.key.get_pressed()[pygame.K_UP]:
			drawer.set_pacman_direction('u')

		elif pygame.key.get_pressed()[pygame.K_DOWN]:
			drawer.set_pacman_direction('d')

		elif pygame.key.get_pressed()[pygame.K_LEFT]:
			drawer.set_pacman_direction('l')

		elif pygame.key.get_pressed()[pygame.K_RIGHT]:
			drawer.set_pacman_direction('r')

		#print "Updating pacman"
		drawer.update_pacman()

		#for i in range(4):
		#	dir = drawer.get_ghost_direction(i)
		#	drawer.set_ghost_direction(i, dir)
		#	drawer.update_ghost(i)

		screen.blit(background, (0, 0))
		drawer.draw()
		pygame.display.flip()
		
		clock.tick(60)
