import pygame, os, sys, random

ghostcolor = {}
ghostcolor[0] = (255, 0, 0, 255)		# Red, Blinky ghost
ghostcolor[1] = (255, 128, 255, 255)	# Pink, Pinky ghost
ghostcolor[2] = (128, 255, 255, 255)	# Cyan, Inky ghost
ghostcolor[3] = (255, 128, 0, 255)		# Orange, Clyde ghost
ghostcolor[4] = (50, 50, 255, 255)		# Blue, vulnerable ghost
ghostcolor[5] = (255, 255, 255, 255)	# White, flashing ghost

class Ghost(pygame.sprite.Sprite):
	def __init__ (self, max_width, max_height, g_id, player):
		pygame.sprite.Sprite.__init__(self)
		
		self.pacman = player
		
		self.velX = 0
		self.velY = 0
		self.speed = 1
		
		self.id = g_id
		self.state = 1
		
		if self.id == 0:
			self.homeX = 10 * 16
			self.homeY = 10 * 16
			self.nearest_row = 10
			self.nearest_col = 10
			self.path = [(1, 0, 48), (0, 1, 96), (1, 0, 16), (0, 1, 64), (1, 0, 48), (0, 1, 32), (-1, 0, 128), \
						(0, -1, 64), (-1, 0, 48), (0, -1, 32), (1, 0, 16), (0, -1, 96), (-1, 0, 16), (0, -1, 32), \
						(-1, 0, 64), (0, -1, 96), (1, 0, 64), (0, 1, 32), (1, 0, 32), (0, 1, 32), (1, 0, 32), \
						(0, 1, 32), (1, 0, 64), (0, 1, 32), (-1, 0, 16), (0, 1, 96)]
		elif self.id == 1:
			self.homeX = 9 * 16
			self.homeY = 12 * 16
			self.nearest_row = 12
			self.nearest_col = 9
			self.path = [(1, 0, 16), (0, -1, 32), (-1, 0, 48), (0, 1, 96), (-1, 0, 16), (0, 1, 64), (-1, 0, 48), \
						(0, 1, 16), (-1, 0, 32), (0, 1, 32), (1, 0, 32), (0, -1, 16), (1, 0, 224), (0, 1, 16), \
						(1, 0, 32), (0, -1, 32), (-1, 0, 32), (0, -1, 48), (-1, 0, 16), (0, -1, 160), (1, 0, 32), \
						(0, -1, 64), (-1, 0, 32), (0, -1, 32), (-1, 0, 96), (0, 1, 96), (1, 0, 64), (0, 1, 32), \
						(-1, 0, 64)]
		elif self.id == 2:
			self.homeX = 10 * 16
			self.homeY = 12 * 16
			self.nearest_row = 12
			self.nearest_col = 10
			self.path = [(0, -1, 32), (1, 0, 48), (0, 1, 96), (-1, 0, 96), (0, -1, 96), (-1, 0, 16), (0, -1, 32), \
						(1, 0, 64), (0, -1, 32), (1, 0, 32), (0, -1, 32), (1, 0, 32), (0, -1, 32), (-1, 0, 64), \
						(0, 1, 64), (-1, 0, 32), (0, -1, 32), (-1, 0, 32), (0, 1, 32), (-1, 0, 32), (0, 1, 128), \
						(-1, 0, 32), (0, 1, 32), (1, 0, 32), (0, 1, 32), (-1, 0, 16), (0, 1, 64), (1, 0, 160), \
						(0, -1, 32), (1, 0, 16), (0, -1, 32), (1, 0, 32), (0, -1, 32), (1, 0, 32), (0, -1, 32), \
						(-1, 0, 32), (0, -1, 96), (-1, 0, 32), (0, 1, 32), (-1, 0, 16)]
		elif self.id == 3:
			self.homeX = 11 * 16
			self.homeY = 12 * 16
			self.nearest_row = 12
			self.nearest_col = 11
			self.path = [(-1, 0, 16), (0, -1, 32), (-1, 0, 48), (0, 1, 32), (-1, 0, 48), (0, 1, 96), (-1, 0, 16), \
						(0, 1, 32), (1, 0, 48), (0, -1, 64), (1, 0, 16), (0, -1, 96), (-1, 0, 16), (0, -1, 32), \
						(-1, 0, 64), (0, -1, 96), (1, 0, 256), (0, 1, 96), (-1, 0, 32), (0, 1, 160), (-1, 0, 80), \
						(0, 1, 64), (-1, 0, 32), (0, -1, 64), (-1, 0, 48), (0, -1, 32), (1, 0, 16), (0, -1, 32), \
						(1, 0, 96), (0, -1, 64), (-1, 0, 48)]
		
		self.path_index = 0
		self.path_count = self.path[self.path_index][2]
		
		self.maxX = max_width
		self.maxY = max_height
		
		self.sprite_ghost = {}
		for i in range(1, 7):
			self.sprite_ghost[i] = pygame.image.load("images/ghost-" + str(i) + ".gif").convert()
			
			# Change the ghost color
			for y in range(0, 16):
				for x in range(0, 16):
					# The default color in the gifs is red
					if self.sprite_ghost[i].get_at((x, y)) == (255, 0, 0, 255):
						self.sprite_ghost[i].set_at((x, y), ghostcolor[self.id])
		
		self.image = self.sprite_ghost[1]
		self.rect = self.image.get_rect()
		self.rect.topleft = (self.homeX, self.homeY)
		
		input = open( os.path.join( "levels", "level.txt" ), 'r')
		self.tile_id = input.readlines()
		for row in self.tile_id:
			self.tile_id[self.tile_id.index(row)] = row.split()
		
		self.sprite_number = 1
		self.sprite_delay = 0

	def update (self):
	
		if self.rect.left <= 0 and self.velX < 0:
			self.rect.left = self.maxX - self.rect.width
		if self.rect.right >= self.maxX and self.velX > 0:
			self.rect.left = 0
		if self.rect.top <= 0 and self.velY < 0:
			self.rect.top = self.maxY - self.rect.height
		if self.rect.bottom >= self.maxY and self.velY > 0:
			self.rect.top = 0
		
		# Ghost eyes
		for y in range(4, 8, 1):
			for x in range(3, 7, 1):
				self.sprite_ghost[self.sprite_number].set_at((x, y), (255, 255, 255, 255))
				self.sprite_ghost[self.sprite_number].set_at((x+6, y), (255, 255, 255, 255))

				if self.pacman.rect.center[0] > self.rect.center[0] and self.pacman.rect.center[1] > self.rect.center[1]:
					# Pacman is to lower-right
					pupil_set = (5, 6)
				elif self.pacman.rect.center[0] < self.rect.center[0] and self.pacman.rect.center[1] > self.rect.center[1]:
					# Pacman is to lower-left
					pupil_set = (3, 6)
				elif self.pacman.rect.center[0] > self.rect.center[0] and self.pacman.rect.center[1] < self.rect.center[1]:
					# Pacman is to upper-right
					pupil_set = (5, 4)
				elif self.pacman.rect.center[0] < self.rect.center[0] and self.pacman.rect.center[1] < self.rect.center[1]:
					# Pacman is to upper-left
					pupil_set = (3, 4)
				else:
					pupil_set = (4, 6)
					
		for y in range(pupil_set[1], pupil_set[1] + 2, 1):
			for x in range(pupil_set[0], pupil_set[0] + 2, 1):
				self.sprite_ghost[self.sprite_number].set_at( (x, y), (0, 0, 255, 255) )
				self.sprite_ghost[self.sprite_number].set_at( (x+6, y), (0, 0, 255, 255) )

		if self.path_index == len(self.path):
			self.path_index = 2
			self.path_count = self.path[self.path_index][2]
		
		nextX = self.path[self.path_index][0]
		nextY = self.path[self.path_index][1]
		self.path_count -= 1
		if self.path_count == 0:
			self.path_index += 1
			if self.path_index < len(self.path):
				self.path_count = self.path[self.path_index][2]

		self.velX = nextX
		self.velY = nextY

		self.rect.left += self.velX
		self.rect.top += self.velY

		self.sprite_delay += 1
		if self.sprite_delay == 4:
			self.sprite_number = (self.sprite_number + 1) % 6 + 1
			self.sprite_delay = 0

		self.image = self.sprite_ghost[self.sprite_number]


	def reset(self):
		self.image = self.sprite_ghost[1]
		self.rect.topleft = (self.homeX, self.homeY)
		self.velX = 0
		self.velY = 0
		self.path_index = 0
		self.path_count = self.path[self.path_index][2]


	def get_coordinates(self):
		return self.rect.topleft
