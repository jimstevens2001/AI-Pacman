import pygame, os, sys

class Level:
	
	def __init__ (self, width, height, screen):
		self.width = width
		self.height = height
		self.tile_size = 16
		self.edge_light_color = (0, 0, 255, 255)
		self.edge_shadow_color = (0, 0, 255, 255)
		self.fill_color = (0, 0, 127, 255)
		self.pellet_color = (255, 255, 255, 255)
		
		self.screen = screen

		self.map = {}
		
		self.pellets = 192
		self.powerdot_timer = 0
		
		self.tile_references = [105, 106, 107, 108, 110, 111, 112, 113, 120, 100, 101, 130, 131, 132, 133, 140, 1, 2, 3]
		self.tile_names = ["wall-corner-ll", "wall-corner-lr", "wall-corner-ul", "wall-corner-ur", 
							"wall-end-b", "wall-end-l", "wall-end-r", "wall-end-t", "wall-nub",
							"wall-straight-horiz", "wall-straight-vert", "wall-t-bottom",
							"wall-t-left", "wall-t-right", "wall-t-top", "wall-x", "ghost-door", "pellet", "pellet-power"]
		self.tiles = {}

		for tile_name in self.tile_names:
			self.tiles[tile_name] = pygame.image.load("images/" + tile_name + ".gif").convert()
			
			for y in range(0, 16, 1):
				for x in range(0, 16, 1):
	
					if self.tiles[tile_name].get_at((x, y)) == (255, 206, 255, 255):
						# Wall edge
						self.tiles[tile_name].set_at((x, y), self.edge_light_color)
	
					elif self.tiles[tile_name].get_at((x, y)) == (132, 0, 132, 255):
						# Wall fill
						self.tiles[tile_name].set_at((x, y), self.fill_color)
	
					elif self.tiles[tile_name].get_at((x, y)) == (255, 0, 255, 255):
						# Pellet color
						self.tiles[tile_name].set_at((x, y), self.edge_shadow_color)
	
					elif self.tiles[tile_name].get_at((x, y)) == (128, 0, 128, 255):
						# pellet color
						self.tiles[tile_name].set_at((x, y), self.pellet_color)
		
		input = open( os.path.join( "levels", "level.txt" ), 'r')
		self.tile_id = input.readlines()
		for row in self.tile_id:
			self.tile_id[self.tile_id.index(row)] = row.split()
			
		# print self.tile_id

		
	def draw_level(self, player_coordinates):
		row = 0
		col = 0
		playerX = int(player_coordinates[0] / 16)
		playerY = int(player_coordinates[1] / 16)
		if self.tile_id[playerY][playerX] == '2':
			self.tile_id[playerY][playerX] = '0'
			self.pellets -= 1
			if self.pellets == 0:
				return True
		while row < self.height:
			while col < self.width:
				tile_id = self.tile_id[row][col]
				if int(tile_id) in self.tile_references:
					tile_name = self.tile_names[self.tile_references.index(int(tile_id))]
					tile = self.tiles[tile_name]
				
					x_coord = col * self.tile_size
					y_coord = row * self.tile_size
					self.screen.blit(tile, (x_coord, y_coord))
				col += 1
				
			row+= 1
			col = 0
		return False
	
	def reset(self):
		self.pellets = 192
		input = open("level.txt", 'r')
		self.tile_id = input.readlines()
		for row in self.tile_id:
			self.tile_id[self.tile_id.index(row)] = row.split()
