import pygame, sys, os, time
import ghost, pacman, level
from pygame.locals import *

clock = pygame.time.Clock()
pygame.init()

window = pygame.display.set_mode((1, 1))
pygame.display.set_caption("PLAKMAN")
pygame.display.set_icon(pygame.transform.scale(pygame.image.load("images/pacman-r3.gif").convert(), (32, 32)))

screen = pygame.display.get_surface()


def sprite_collision(main_sprite, group):
	for item in group.sprites():
		if main_sprite.rect.colliderect(item.rect):
			return True


def reset_sprites(sprites):
	for sprite in sprites.sprites():
		sprite.reset()



if __name__ == "__main__":

	tiles_x = 21
	tiles_y = 25
	width = tiles_x * 16 - 1
	height = tiles_y * 16 - 1
	window = pygame.display.set_mode((width, height))
	background = pygame.Surface(screen.get_size())
	background = background.convert()
	background.fill((0,0,0))

	screen.blit(background, (0,0))
	pygame.display.flip()
	
	level = level.Level(tiles_x, tiles_y, screen)

	pacman = pacman.Pacman(width, height)
	blinky = ghost.Ghost(width, height, 0, pacman)
	pinky = ghost.Ghost(width, height, 1, pacman)
	inky = ghost.Ghost(width, height, 2, pacman)
	clyde = ghost.Ghost(width, height, 3, pacman)
	ghosts = pygame.sprite.RenderPlain((blinky, pinky, inky, clyde))
	allsprites = pygame.sprite.RenderPlain((pacman, blinky, pinky, inky, clyde))

	while True:

		pygame.event.pump()
		if pygame.key.get_pressed()[pygame.K_ESCAPE]:
			sys.exit(0)

		elif pygame.key.get_pressed()[pygame.K_UP]:
			pacman.give_direction('u')

		elif pygame.key.get_pressed()[pygame.K_DOWN]:
			pacman.give_direction('d')

		elif pygame.key.get_pressed()[pygame.K_LEFT]:
			pacman.give_direction('l')

		elif pygame.key.get_pressed()[pygame.K_RIGHT]:
			pacman.give_direction('r')

		allsprites.update()
		if sprite_collision(pacman, ghosts):
			time.sleep(1)
			reset_sprites(allsprites)
		screen.blit(background, (0,0))
		game_over = level.draw_level(pacman.get_coordinates())
		allsprites.draw(screen)

		if game_over:
			time.sleep(1)
			level.reset()
			reset_sprites(allsprites)
		pygame.display.flip()
		
		clock.tick(60)