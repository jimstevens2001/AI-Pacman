import pygame, os, sys

class Pacman(pygame.sprite.Sprite):
	def __init__ (self, max_width, max_height):
		pygame.sprite.Sprite.__init__(self)
		
		self.velX = 0
		self.velY = 0
		self.speed = 2
		
		self.nearest_row = 16
		self.nearest_col = 10
		
		self.homeX = 10 * 16
		self.homeY = 16 * 16
		
		self.maxX = max_width
		self.maxY = max_height

		self.sprite_pacman = {}
		self.sprite_pacmanCurrent = {}
		self.sprite_number = 1
		self.sprite_delay = 0
		
		for dir in ['u', 'd', 'l', 'r', 's']:
			self.sprite_pacman[dir] = {}
			for i in range(1, 9):
				if dir != 's':
					self.sprite_pacman[dir][i] = pygame.image.load("images/pacman-" + dir + str(i) + ".gif").convert()
				else:
					self.sprite_pacman[dir][i] = pygame.image.load("images/pacman.gif").convert()
		
		self.sprite_pacmanCurrent = self.sprite_pacman['s']
		self.image = self.sprite_pacman['s'][1]
		self.rect = self.image.get_rect()
		self.rect = self.rect.inflate(-1, -1)
		self.rect.topleft = (self.homeX, self.homeY)
		
		input = open( os.path.join( "levels", "level.txt" ), 'r')
		self.tile_id = input.readlines()
		for row in self.tile_id:
			self.tile_id[self.tile_id.index(row)] = row.split()

		
	def give_direction (self, direction):
		if direction == 'u' and int(self.tile_id[int((self.rect.topleft[1] - self.speed) / 16)][int(self.rect.topleft[0] / 16)]) < 100 \
			and int(self.tile_id[int((self.rect.topright[1] - self.speed) / 16)][int(self.rect.topright[0] / 16)]) < 100:
			self.velY = -self.speed
			self.velX = 0

		# Have to deal with this for now because self.speed is 2
		if int((self.rect.bottomleft[1] + self.speed) / 16) >= len(self.tile_id):
			return

		if direction == 'd' and int(self.tile_id[int((self.rect.bottomleft[1] + self.speed) / 16)][int(self.rect.bottomleft[0] / 16)]) < 100 \
			and int(self.tile_id[int((self.rect.bottomright[1] + self.speed) / 16)][int(self.rect.bottomright[0] / 16)]) < 100:
			self.velY = self.speed
			self.velX = 0
			
		if direction == 'l' and int(self.tile_id[int(self.rect.topleft[1] / 16)][int((self.rect.topleft[0] - self.speed) / 16)]) < 100 \
			and int(self.tile_id[int(self.rect.bottomleft[1] / 16)][int((self.rect.bottomleft[0] - self.speed) / 16)]) < 100:
			self.velX = -self.speed
			self.velY = 0
		
		# Have to deal with this for now because self.speed is 2
		if int((self.rect.topright[0] + self.speed) / 16) >= len(self.tile_id[int(self.rect.topright[1] / 16)]):
			return
			
		if direction == 'r' and int(self.tile_id[int(self.rect.topright[1] / 16)][int((self.rect.topright[0] + self.speed) / 16)]) < 100 \
			and int(self.tile_id[int(self.rect.bottomright[1] / 16)][int((self.rect.bottomright[0] + self.speed) / 16)]) < 100:
			self.velX = self.speed
			self.velY = 0
		


	
	def update (self):

		# Set the current sprite array to match the direction pacman is facing
		if self.velX > 0:
			self.sprite_pacmanCurrent = self.sprite_pacman['r']
		elif self.velX < 0:
			self.sprite_pacmanCurrent = self.sprite_pacman['l']
		elif self.velY > 0:
			self.sprite_pacmanCurrent = self.sprite_pacman['d']
		elif self.velY < 0:
			self.sprite_pacmanCurrent = self.sprite_pacman['u']
	
		if self.rect.left <= 0 and self.velX < 0:
			self.rect.left = self.maxX - self.rect.width
		if self.rect.right >= self.maxX and self.velX > 0:
			self.rect.left = 0
		if self.rect.top <= 0 and self.velY < 0:
			self.rect.top = self.maxY - self.rect.height
		if self.rect.bottom >= self.maxY and self.velY > 0:
			self.rect.top = 0

		if self.velX < 0:
			checkx = self.rect.left
		else:
			checkx = self.rect.right
		if self.velY < 0:
			checky = self.rect.top
		else:
			checky = self.rect.bottom
		if int(self.tile_id[self.nearest_row][int((checkx + self.velX) / 16)]) < 100:
			self.rect.left += self.velX
		else:
			self.velX = 0

		if int(self.tile_id[int((checky + self.velY) / 16)][self.nearest_col]) < 100:
			self.rect.top += self.velY
		else:
			self.velY = 0
		
		self.nearest_row = int(self.rect.top / 16)
		self.nearest_col = int(self.rect.left / 16)

		if not self.velX == 0 or not self.velY == 0:
			# Only move mouth when PLAKMAN is moving
			self.sprite_delay += 1
			if self.sprite_delay == 3:
				self.sprite_number = (self.sprite_number + 1) % 8 + 1
				self.sprite_delay = 0

		self.image = self.sprite_pacmanCurrent[self.sprite_number]


	def reset(self):
		self.sprite_pacmanCurrent = self.sprite_pacman['s']
		self.rect.topleft = (self.homeX, self.homeY)
		self.velX = 0
		self.velY = 0
	
	
	def get_coordinates(self):
		return self.rect.topleft
