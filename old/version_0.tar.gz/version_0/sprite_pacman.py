import pygame, sys, os
from pygame.locals import *

def load_image(name, colorkey=None):
	fullname = os.path.join('images', name)

	try:
		image = pygame.image.load(fullname)
	except pygame.error, message:
		print "Cannot load image: " + name
		raise SystemExit, message

	image = image.convert()
	if colorkey is not None:
		if colorkey is -1:
			colorkey = image.get_at((0,0))
		image.set_colorkey(colorkey, RLEACCEL)

	return image, image.get_rect()

class Pacman(pygame.sprite.Sprite):

	def __init__(self, top, bottom, left, right):
		pygame.sprite.Sprite.__init__(self)
		self.image, self.rect = load_image("pacman-l1.gif", -1)
		self.index = 1
		self.top = top
		self.bottom = bottom
		self.left = left
		self.right = right
		self.direction = 'l'
		self.counter = 0
		self.stop = 1

	def update(self):
		if (self.stop):
			self.image = pygame.image.load("images/pacman-"+str(self.direction)+str(self.index)+".gif")
		else:
			self.counter += 1
			if self.counter == 10:
				self.index = (self.index + 1) % 8 + 1
				self.image = pygame.image.load("images/pacman-"+str(self.direction)+str(self.index)+".gif")
				self.counter = 0
		previous_x = self.rect.left
		previous_y = self.rect.top
		if self.direction == 'u' and self.rect.top != self.top:
			self.rect.top -= 1
		elif self.direction == 'd' and self.rect.bottom != self.bottom - 1:
			self.rect.top += 1
		elif self.direction == 'r' and self.rect.right != self.right:
			self.rect.left += 1
		elif self.direction == 'l' and self.rect.left != self.left:
			self.rect.left -= 1

		if previous_x == self.rect.left and previous_y == self.rect.top:
			self.stop = 1


	def give_direction(self, new_direction):
		self.direction = new_direction
		self.stop = 0
			
		

if __name__ == "__main__":

	pygame.init()
	height = 400
	width = 400
	screen = pygame.display.set_mode((height, width))
	pygame.display.set_caption("Mouth movement")
	background = pygame.Surface(screen.get_size())
	background = background.convert()
	background.fill((0,0,0))

	screen.blit(background, (0,0))
	pygame.display.flip()

	pacman = Pacman(0, height, 0, width)
	allsprites = pygame.sprite.RenderPlain((pacman))
	clock = pygame.time.Clock()

	while 1:
		clock.tick(1000)

		for event in pygame.event.get():
			if event.type == QUIT:
				sys.exit(0)

			if event.type == KEYDOWN and event.key == K_ESCAPE:
				sys.exit(0)

			if event.type == KEYDOWN and event.key == K_UP:
				pacman.give_direction('u')

			if event.type == KEYDOWN and event.key == K_DOWN:
				pacman.give_direction('d')

			if event.type == KEYDOWN and event.key == K_LEFT:
				pacman.give_direction('l')

			if event.type == KEYDOWN and event.key == K_RIGHT:
				pacman.give_direction('r')

		allsprites.update()
		screen.blit(background, (0,0))
		allsprites.draw(screen)
		pygame.display.flip()
